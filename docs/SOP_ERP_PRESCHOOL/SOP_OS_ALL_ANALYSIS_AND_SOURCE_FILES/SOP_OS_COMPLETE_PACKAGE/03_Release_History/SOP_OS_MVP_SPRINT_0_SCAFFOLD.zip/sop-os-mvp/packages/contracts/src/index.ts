export type DataClassification = 'PUB' | 'INT' | 'CON' | 'HRI';

export type ActorContext = {
  actorId: string;
  organizationId: string;
  campusIds: readonly string[];
  permissions: readonly string[];
  correlationId: string;
};

export type ApiError = {
  code: string;
  message: string;
  correlationId: string;
  fields?: ReadonlyArray<{ field: string; code: string; message: string }>;
};

export type HealthResponse = {
  status: 'ok' | 'degraded';
  service: string;
  version: string;
  timestamp: string;
};

export const leadStatuses = [
  'NEW', 'ASSIGNED', 'CONTACTED', 'QUALIFIED', 'NURTURING',
  'CONVERTED', 'DISQUALIFIED', 'LOST', 'DUPLICATE', 'ARCHIVED'
] as const;

export type LeadStatus = (typeof leadStatuses)[number];

export const sopVersionStatuses = [
  'DRAFT', 'IN_REVIEW', 'REVISION_REQUIRED', 'APPROVED',
  'SCHEDULED', 'EFFECTIVE', 'SUPERSEDED', 'ARCHIVED'
] as const;

export type SopVersionStatus = (typeof sopVersionStatuses)[number];

export type DomainEvent<TPayload extends object = Record<string, never>> = {
  eventId: string;
  eventType: string;
  eventVersion: number;
  aggregateType: string;
  aggregateId: string;
  organizationId: string;
  occurredAt: string;
  correlationId: string;
  causationId?: string;
  payload: TPayload;
};

