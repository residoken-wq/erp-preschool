import { Body, Controller, Post } from '@nestjs/common';
import type { ActorContext } from '@sop-os/contracts';
import { CurrentActor } from '../../platform/actor-context.js';
import { LeadService, type CreateLeadCommand } from './lead.service.js';

@Controller('leads')
export class LeadController {
  constructor(private readonly leads: LeadService) {}

  @Post()
  create(@CurrentActor() actor: ActorContext, @Body() command: CreateLeadCommand): Promise<{ id: string; code: string; status: 'NEW' }> {
    return this.leads.create(actor, command);
  }
}

