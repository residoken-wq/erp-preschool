import { Module } from '@nestjs/common';
import { DatabaseModule } from './platform/database.module.js';
import { HealthModule } from './modules/health/health.module.js';
import { ProcessModule } from './modules/process/process.module.js';
import { SopModule } from './modules/sop/sop.module.js';
import { AdmissionModule } from './modules/admission/admission.module.js';

@Module({
  imports: [DatabaseModule, HealthModule, ProcessModule, SopModule, AdmissionModule]
})
export class AppModule {}

