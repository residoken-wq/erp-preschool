import { Controller, Get, Inject, Query } from '@nestjs/common';
import type { Pool } from 'pg';
import type { ActorContext } from '@sop-os/contracts';
import { CurrentActor } from '../../platform/actor-context.js';
import { PG_POOL } from '../../platform/database.module.js';

type SopRow = {
  id: string;
  code: string;
  title: string;
  sop_type: 'OPERATIONAL' | 'CONTROL' | 'MANAGEMENT' | 'COMPLIANCE';
  priority: 'P0' | 'P1' | 'P2';
  lifecycle_status: 'ACTIVE' | 'RETIRED';
  version_label: string | null;
  version_status: string | null;
};

@Controller('sops')
export class SopController {
  constructor(@Inject(PG_POOL) private readonly pool: Pool) {}

  @Get()
  async list(@CurrentActor() actor: ActorContext, @Query('q') query?: string): Promise<SopRow[]> {
    const q = query?.trim() ?? '';
    const result = await this.pool.query<SopRow>(
      `SELECT s.id, s.code, s.title, s.sop_type, s.priority, s.lifecycle_status,
              v.version_label, v.status AS version_status
       FROM sops s
       LEFT JOIN LATERAL (
         SELECT version_label, status FROM sop_versions sv
         WHERE sv.sop_id = s.id
         ORDER BY CASE WHEN status = 'EFFECTIVE' THEN 0 ELSE 1 END, version_number DESC
         LIMIT 1
       ) v ON true
       WHERE s.organization_id = $1
         AND ($2 = '' OR s.code ILIKE '%' || $2 || '%' OR s.title ILIKE '%' || $2 || '%')
       ORDER BY s.code LIMIT 100`,
      [actor.organizationId, q]
    );
    return result.rows;
  }
}
