const tasks = [
  { title: 'APP-2026-0148 thiếu giấy khai sinh', meta: 'Quá hạn 2 giờ', status: 'Incomplete' },
  { title: 'Offer OFF-2026-0082 chờ approval', meta: 'Hạn 17:00 hôm nay', status: 'Pending' },
  { title: 'Handover ENR-2026-0061 bị trả lại', meta: 'Thiếu consent hình ảnh', status: 'Returned' }
];

export default function DashboardPage() {
  return (
    <div className="appShell">
      <aside className="sidebar">
        <div className="brand"><span className="brandMark">S</span><span>SOP OS</span></div>
        <nav aria-label="Điều hướng chính">
          {['Tổng quan', 'Quy trình', 'Thư viện SOP', 'Công việc', 'Tuyển sinh', 'Danh mục', 'Báo cáo', 'Quản trị'].map((item, index) => (
            <a key={item} className={index === 0 ? 'navItem active' : 'navItem'} href="#">{item}</a>
          ))}
        </nav>
      </aside>
      <main className="main">
        <header className="topbar"><span>Tổng quan / Công việc của tôi</span><button type="button">Cơ sở Trung tâm</button></header>
        <div className="content">
          <div className="pageHead"><div><h1>Tổng quan</h1><p>Chào buổi sáng, Admission Manager</p></div><button className="primary" type="button">+ Tạo Lead</button></div>
          <section className="metrics" aria-label="Chỉ số chính">
            <article><span>Cần xử lý hôm nay</span><strong>12</strong><small>3 việc quá hạn</small></article>
            <article><span>Application đang review</span><strong>18</strong><small>5 hồ sơ mới</small></article>
            <article><span>Offer sắp hết hạn</span><strong>4</strong><small>Trong 48 giờ</small></article>
          </section>
          <section className="panel">
            <h2>Ưu tiên xử lý</h2>
            {tasks.map((task) => (
              <div className="task" key={task.title}><div><strong>{task.title}</strong><span>{task.meta}</span></div><em>{task.status}</em></div>
            ))}
          </section>
        </div>
      </main>
    </div>
  );
}

