import { BadRequestException, Inject, Injectable } from '@nestjs/common';
import type { ActorContext } from '@sop-os/contracts';
import type { Pool, PoolClient } from 'pg';
import { randomUUID } from 'node:crypto';
import { PG_POOL } from '../../platform/database.module.js';

export type CreateLeadCommand = {
  code: string;
  firstName: string;
  lastName: string;
  sourceType: string;
  campusId?: string;
};

@Injectable()
export class LeadService {
  constructor(@Inject(PG_POOL) private readonly pool: Pool) {}

  async create(actor: ActorContext, command: CreateLeadCommand): Promise<{ id: string; code: string; status: 'NEW' }> {
    if (!command.code || !command.firstName || !command.lastName || !command.sourceType) {
      throw new BadRequestException('code, firstName, lastName and sourceType are required');
    }
    if (command.campusId && !actor.campusIds.includes(command.campusId)) {
      throw new BadRequestException('Campus is outside the actor scope');
    }

    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const personId = randomUUID();
      const leadId = randomUUID();
      await this.insertPerson(client, actor, personId, command);
      await client.query(
        `INSERT INTO leads(id, organization_id, code, primary_contact_person_id, campus_id, source_type, status)
         VALUES ($1, $2, $3, $4, $5, $6, 'NEW')`,
        [leadId, actor.organizationId, command.code, personId, command.campusId ?? null, command.sourceType]
      );
      await client.query(
        `INSERT INTO audit_events(organization_id, actor_type, actor_id, action, object_type, object_id, after_json, correlation_id)
         VALUES ($1, 'USER', $2, 'lead.create', 'Lead', $3, $4::jsonb, $5)`,
        [actor.organizationId, actor.actorId, leadId, JSON.stringify({ code: command.code, status: 'NEW' }), actor.correlationId]
      );
      await client.query(
        `INSERT INTO outbox_events(organization_id, event_type, aggregate_type, aggregate_id, payload_json, correlation_id)
         VALUES ($1, 'LeadCreated', 'Lead', $2, $3::jsonb, $4)`,
        [actor.organizationId, leadId, JSON.stringify({ leadId, code: command.code }), actor.correlationId]
      );
      await client.query('COMMIT');
      return { id: leadId, code: command.code, status: 'NEW' };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  private async insertPerson(client: PoolClient, actor: ActorContext, id: string, command: CreateLeadCommand): Promise<void> {
    await client.query(
      `INSERT INTO persons(id, organization_id, first_name, last_name, data_classification)
       VALUES ($1, $2, $3, $4, 'HRI')`,
      [id, actor.organizationId, command.firstName, command.lastName]
    );
  }
}

