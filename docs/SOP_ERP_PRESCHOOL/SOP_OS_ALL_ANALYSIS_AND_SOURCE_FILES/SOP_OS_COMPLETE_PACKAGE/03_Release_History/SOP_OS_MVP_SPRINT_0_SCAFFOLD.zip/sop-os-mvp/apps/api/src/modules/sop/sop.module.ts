import { Module } from '@nestjs/common';
import { SopController } from './sop.controller.js';

@Module({ controllers: [SopController] })
export class SopModule {}

