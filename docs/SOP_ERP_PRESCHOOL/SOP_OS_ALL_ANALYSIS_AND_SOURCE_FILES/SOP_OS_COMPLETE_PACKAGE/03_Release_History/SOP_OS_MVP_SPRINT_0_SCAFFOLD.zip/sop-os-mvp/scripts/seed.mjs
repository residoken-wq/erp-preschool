import { readFile } from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import pg from 'pg';

const { Client } = pg;
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('DATABASE_URL is required');

const seedPath = path.resolve(process.argv[2] ?? 'database/seed/demo-seed.json');
const seed = JSON.parse(await readFile(seedPath, 'utf8'));
const client = new Client({ connectionString: databaseUrl });
await client.connect();

async function upsertOrganization() {
  const o = seed.organization;
  await client.query(
    `INSERT INTO organizations(id, code, name, default_timezone, default_locale, status)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (code) DO UPDATE SET name = EXCLUDED.name, updated_at = now(), row_version = organizations.row_version + 1`,
    [o.id, o.code, o.name, o.default_timezone ?? 'Asia/Ho_Chi_Minh', o.default_locale ?? 'vi-VN', o.status ?? 'ACTIVE']
  );
}

async function seedCampuses() {
  for (const campus of seed.campuses ?? []) {
    await client.query(
      `INSERT INTO campuses(id, organization_id, code, name, status)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (organization_id, code) DO UPDATE SET name = EXCLUDED.name, status = EXCLUDED.status, updated_at = now(), row_version = campuses.row_version + 1`,
      [campus.id, seed.organization.id, campus.code, campus.name, campus.status ?? 'ACTIVE']
    );
  }
}

async function seedRoles() {
  for (const role of seed.roles ?? []) {
    await client.query(
      `INSERT INTO roles(organization_id, code, name) VALUES ($1, $2, $3)
       ON CONFLICT (organization_id, code) DO UPDATE SET name = EXCLUDED.name`,
      [seed.organization.id, role.code, role.name]
    );
  }
}

async function seedUsers() {
  for (const user of seed.demo_users ?? []) {
    await client.query(
      `INSERT INTO user_accounts(id, organization_id, email_normalized, display_name, status)
       VALUES ($1, $2, lower($3), $4, 'ACTIVE')
       ON CONFLICT (organization_id, email_normalized) DO UPDATE SET display_name = EXCLUDED.display_name, status = 'ACTIVE'`,
      [user.id, seed.organization.id, user.email, user.display_name]
    );
    for (const roleCode of user.roles ?? []) {
      for (const campusCode of user.campuses ?? [null]) {
        await client.query(
          `INSERT INTO user_role_scopes(organization_id, user_id, role_id, campus_id)
           SELECT $1, $2, r.id, c.id
           FROM roles r
           LEFT JOIN campuses c ON c.organization_id = $1 AND c.code = $4
           WHERE r.organization_id = $1 AND r.code = $3
             AND NOT EXISTS (
               SELECT 1 FROM user_role_scopes urs
               WHERE urs.user_id = $2 AND urs.role_id = r.id AND urs.campus_id IS NOT DISTINCT FROM c.id AND urs.valid_to IS NULL
             )`,
          [seed.organization.id, user.id, roleCode, campusCode]
        );
      }
    }
  }
}

async function seedProcesses() {
  const ids = new Map();
  for (const node of seed.process_nodes ?? []) {
    const parentId = node.parent ? ids.get(node.parent) : null;
    const result = await client.query(
      `INSERT INTO process_nodes(organization_id, parent_id, level, code, name)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (organization_id, code) DO UPDATE SET name = EXCLUDED.name, parent_id = EXCLUDED.parent_id
       RETURNING id`,
      [seed.organization.id, parentId, node.level, node.code, node.name]
    );
    ids.set(node.code, result.rows[0].id);
  }
  return ids;
}

async function seedSops(processIds) {
  for (const sop of seed.sop_register ?? []) {
    const processId = processIds.get(sop.code);
    if (!processId) continue;
    await client.query(
      `INSERT INTO sops(organization_id, process_node_id, code, title, sop_type, owner_role_id, priority)
       SELECT $1, $2, $3, $4, $5, r.id, $7
       FROM roles r WHERE r.organization_id = $1 AND r.code = $6
       ON CONFLICT (organization_id, code) DO UPDATE SET title = EXCLUDED.title, owner_role_id = EXCLUDED.owner_role_id`,
      [seed.organization.id, processId, sop.code, sop.title, sop.type, sop.owner_role, sop.priority ?? 'P0']
    );
  }
}

try {
  await client.query('BEGIN');
  await upsertOrganization();
  await seedCampuses();
  await seedRoles();
  await seedUsers();
  const processIds = await seedProcesses();
  await seedSops(processIds);
  await client.query('COMMIT');
  console.log(`Seed complete from ${seedPath}`);
} catch (error) {
  await client.query('ROLLBACK');
  throw error;
} finally {
  await client.end();
}

