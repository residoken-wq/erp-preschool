import { createParamDecorator, type ExecutionContext, ForbiddenException } from '@nestjs/common';
import type { Request } from 'express';
import type { ActorContext } from '@sop-os/contracts';

export const CurrentActor = createParamDecorator((_data: unknown, context: ExecutionContext): ActorContext => {
  const request = context.switchToHttp().getRequest<Request>();
  if (process.env.AUTH_MODE !== 'development') {
    throw new ForbiddenException('OIDC authentication adapter is not configured in this scaffold');
  }
  const actorId = request.header('x-actor-id') ?? '00000000-0000-7000-8000-000000001001';
  const organizationId = request.header('x-organization-id') ?? '00000000-0000-7000-8000-000000000001';
  const campusHeader = request.header('x-campus-ids') ?? '00000000-0000-7000-8000-000000000101';

  return {
    actorId,
    organizationId,
    campusIds: campusHeader.split(',').map((value) => value.trim()),
    permissions: ['development:*'],
    correlationId: request.header('x-correlation-id') ?? 'unknown'
  };
});

