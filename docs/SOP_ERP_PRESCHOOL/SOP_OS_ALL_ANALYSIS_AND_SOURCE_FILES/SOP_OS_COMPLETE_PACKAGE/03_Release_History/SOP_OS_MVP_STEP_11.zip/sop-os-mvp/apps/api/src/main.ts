import 'reflect-metadata';
import { randomUUID } from 'node:crypto';
import { NestFactory } from '@nestjs/core';
import type { NextFunction, Request, Response } from 'express';
import { AppModule } from './app.module.js';
import { HttpErrorFilter } from './platform/http-error.filter.js';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });
  app.setGlobalPrefix('api/v1');
  app.enableCors({
    origin: process.env.APP_ORIGIN ?? 'http://localhost:3000',
    credentials: true
  });
  app.use((request: Request, response: Response, next: NextFunction) => {
    const correlationId = request.header('x-correlation-id') ?? randomUUID();
    response.setHeader('x-correlation-id', correlationId);
    request.headers['x-correlation-id'] = correlationId;
    next();
  });
  app.useGlobalFilters(new HttpErrorFilter());
  app.enableShutdownHooks();

  const port = Number(process.env.API_PORT ?? 3001);
  await app.listen(port, '0.0.0.0');
}

await bootstrap();

