import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  API_PORT: z.coerce.number().int().positive().default(3001),
  DATABASE_URL: z.string().min(1),
  APP_ORIGIN: z.string().url(),
  AUTH_MODE: z.enum(['development', 'oidc']).default('development'),
  OIDC_ISSUER: z.string().url().optional(),
  OIDC_CLIENT_ID: z.string().optional(),
  OIDC_CLIENT_SECRET: z.string().optional(),
  OUTBOX_POLL_INTERVAL_MS: z.coerce.number().int().min(250).default(2000),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info')
});

export type AppEnvironment = z.infer<typeof envSchema>;

export function loadEnvironment(input: NodeJS.ProcessEnv = process.env): AppEnvironment {
  const parsed = envSchema.safeParse(input);
  if (!parsed.success) {
    throw new Error(`Invalid environment: ${z.prettifyError(parsed.error)}`);
  }
  if (parsed.data.AUTH_MODE === 'oidc') {
    if (!parsed.data.OIDC_ISSUER || !parsed.data.OIDC_CLIENT_ID) {
      throw new Error('OIDC_ISSUER and OIDC_CLIENT_ID are required when AUTH_MODE=oidc');
    }
  }
  return parsed.data;
}

